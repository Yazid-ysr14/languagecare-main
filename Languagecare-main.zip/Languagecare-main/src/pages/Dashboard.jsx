import Navs from "../components/header/Navbar";
import SideBar from "../components/main/sidebar/SideBar";

function Dashboard() {
  return (
    <section>
      <SideBar />
    </section>
  );
}

export default Dashboard;
